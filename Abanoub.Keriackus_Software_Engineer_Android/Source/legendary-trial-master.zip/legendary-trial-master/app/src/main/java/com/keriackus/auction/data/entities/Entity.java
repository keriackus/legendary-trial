package com.keriackus.auction.data.entities;

import java.io.Serializable;

/**
 * Created by keriackus on 4/1/2016.
 */
public class Entity  implements Serializable{

    public Entity() {
    }
}
