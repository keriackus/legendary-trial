package com.keriackus.auction.presentation.views.activities;

/**
 * Created by keriackus on 4/1/2016.
 */
public interface ViewListener {

    public void onUpdate(Object... params);

    public void onError(int StringResId);
}
